package com.example.bs_rashhuli

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
