class OnBoradingModel {
  final String image;
  final String title;
  final String description;

  OnBoradingModel({
    required this.image,
    required this.title,
    required this.description,
  });
}
