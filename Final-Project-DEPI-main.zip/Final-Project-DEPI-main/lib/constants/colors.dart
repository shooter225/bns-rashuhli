import 'package:flutter/material.dart';

const kMainColor = Color(0xff005738);